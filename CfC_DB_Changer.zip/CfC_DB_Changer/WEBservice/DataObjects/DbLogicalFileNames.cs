﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CfCServiceTester.WEBservice.DataObjects
{
    /// <summary>
    /// Logical file names in the backup file
    /// </summary>
    public class DbLogicalFileNames
    {
        public string LogicalNameData { get; set; }
        public string LogicalNameLog { get; set; }
    }
}